package pageObjects;

public class DynamicLoadding {
	String linkTextHidden = "Example 1: Element on page that is hidden";
	String linkTextRender = "Example 2: Element rendered after the fact";
	
	
	String cssStartButton = "div#start>button";
	
	String cssProgressbar = "div#loading>img";
	
	String cssH4Header = "div#finish>h4";
	
	
}
