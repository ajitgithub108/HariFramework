package pageObjects;

public class CheckDropdown {
	
	String idDropdown = "dropdown";

}
