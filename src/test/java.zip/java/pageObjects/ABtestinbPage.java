package pageObjects;

public class ABtestinbPage {
   String  xpatrelativehabTeasting = "//h3";
   String  xpatabsabTeasting = "/html/body/div[2]/div/div/h3";
   String xpathParagraph = "//div[@class='example']/p";
}
